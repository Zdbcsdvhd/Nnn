#### YouTube Video Download Bot
###### This A simple YouTube Video Download Telegram Bot


![logo](https://graph.org/file/754b7faa1308a13fc917f.jpg)


# Deploy

## Environment Variable

* `APP_ID` Get it From mytelegram.org

* `API_HASH` Get it From mytelegram.org

* `BOT_TOKEN` Get it from [@Botfather](https://t.me/botfather)


### My Community Details



- Telegram Channel : [AIIMS MOTIVATION❤️‍🩹](https://t.me/AIM_AIIMS143)
- My Tg Id : [Tushar👑](https://t.me/Tushar_1665)
